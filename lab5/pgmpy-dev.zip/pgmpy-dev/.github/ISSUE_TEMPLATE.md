### Subject of the issue
Describe your issue here.

### Your environment
* pgmpy version
* Python version
* Operating System

### Steps to reproduce
Tell us how to reproduce this issue. Please provide the complete code if possible.

### Expected behaviour
Tell us what should happen

### Actual behaviour
Tell us what happens instead
